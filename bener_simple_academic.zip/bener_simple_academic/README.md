# Bener Su Academic Homepage

A simple one-page academic homepage for Bener Su.

## Update

Edit `index.html`, `styles.css`, and `script.js`, then upload them to the root of `somber9.github.io`.
