import Image from 'next/image';
import { ArrowDownRight, Mail } from 'lucide-react';

export default function Home() {
  return (
    <main className="relative z-10 min-h-screen">
      <header className="mx-auto flex w-full max-w-7xl items-center justify-between px-6 py-7 md:px-10">
        <a href="#top" className="text-[21px] font-semibold tracking-tight text-ink">
          Somber
        </a>
        <nav className="hidden items-center gap-9 text-[15px] text-ink md:flex">
          <a className="nav-link" href="#research">Research</a>
          <a className="nav-link" href="#projects">Projects</a>
          <a className="nav-link" href="#beyond">Beyond</a>
          <a className="nav-link" href="mailto:sober_9@foxmail.com">Contact</a>
        </nav>
      </header>

      <section id="top" className="mx-auto grid min-h-[calc(100vh-92px)] w-full max-w-7xl grid-cols-1 items-center gap-16 px-6 pb-20 pt-10 md:grid-cols-[1fr_0.86fr] md:px-10 md:pt-0">
        <div>
          <p className="mb-8 text-[13px] font-semibold uppercase tracking-[0.28em] text-clay">
            Bener Su · AI for Healthcare
          </p>
          <h1 className="max-w-3xl text-[58px] font-semibold leading-[0.95] tracking-[-0.055em] text-ink md:text-[92px] lg:text-[112px]">
            让一朵云推动另一朵云。
          </h1>
          <p className="mt-8 max-w-2xl text-[21px] leading-8 tracking-[-0.02em] text-muted md:text-[24px] md:leading-9">
            Passing forward the kindness I have received, through research.
          </p>

          <div className="mt-14 flex flex-col gap-4 border-l border-line pl-6 text-[17px] leading-8 text-ink">
            <p>
              I am an undergraduate researcher in Biomedical Engineering at Nanjing University,
              exploring brain-computer interfaces, AI for healthcare, and neural signal processing.
            </p>
            <p className="text-muted">
              I hope to build AI systems that understand the brain and serve people.
            </p>
          </div>

          <div className="mt-10 flex flex-wrap gap-3">
            <a href="#research" className="inline-flex items-center gap-2 rounded-full border border-ink bg-ink px-5 py-3 text-[15px] font-medium text-paper transition hover:-translate-y-0.5">
              Explore research <ArrowDownRight size={17} />
            </a>
            <a href="mailto:sober_9@foxmail.com" className="inline-flex items-center gap-2 rounded-full border border-line px-5 py-3 text-[15px] font-medium text-ink transition hover:-translate-y-0.5 hover:border-ink">
              <Mail size={17} /> Contact
            </a>
          </div>
        </div>

        <figure className="relative mx-auto w-full max-w-[520px] md:ml-auto">
          <div className="absolute -inset-5 -z-10 rounded-[2.2rem] bg-white/45 blur-2xl" />
          <Image
            src="/images/forest-photo.jpeg"
            alt="Bener Su in a forest"
            width={900}
            height={1200}
            priority
            className="aspect-[4/5] w-full rounded-[1.6rem] border border-line object-cover object-[48%_22%] shadow-[0_32px_90px_rgba(35,31,24,0.14)]"
          />
          <figcaption className="mt-4 text-right text-[13px] text-muted">
            Outside the lab, still looking for quiet questions.
          </figcaption>
        </figure>
      </section>

      <section id="research" className="border-t border-line bg-[#fbfaf7]">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-10 px-6 py-24 md:grid-cols-[0.35fr_1fr] md:px-10">
          <div>
            <span className="text-[13px] text-muted">01</span>
            <h2 className="mt-6 font-serif text-[46px] leading-none text-ink">Research</h2>
          </div>
          <div className="grid gap-8 md:grid-cols-[0.9fr_1.1fr]">
            <div>
              <p className="text-[13px] font-semibold uppercase tracking-[0.24em] text-clay">Current project</p>
              <h3 className="mt-5 text-[34px] font-semibold tracking-[-0.04em] text-ink">BrainNeRF</h3>
              <p className="mt-3 max-w-md text-[17px] leading-7 text-muted">
                Physics-guided neural field for EEG spatial super-resolution, recovering high-density neural activity from sparse electrode observations.
              </p>
              <p className="mt-5 inline-flex rounded-full bg-[#efe7df] px-4 py-2 text-[14px] text-ink">Preparing AAAI submission</p>
            </div>
            <div className="rounded-[1.4rem] border border-line bg-paper p-8">
              <div className="grid grid-cols-3 items-center gap-5 text-center text-[13px] font-medium text-ink">
                <div>
                  <div className="mx-auto mb-4 grid h-28 w-28 place-items-center rounded-full border border-line bg-white text-[12px] text-muted">Sparse EEG</div>
                  EEG Sensors
                </div>
                <div>
                  <div className="mx-auto mb-4 grid h-28 w-28 place-items-center rounded-2xl border border-line bg-white text-[12px] text-muted">BrainNeRF</div>
                  Neural Field
                </div>
                <div>
                  <div className="mx-auto mb-4 grid h-28 w-28 place-items-center rounded-full border border-line bg-white text-[12px] text-muted">32-ch EEG</div>
                  Reconstruction
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="projects" className="border-t border-line">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-10 px-6 py-24 md:grid-cols-[0.35fr_1fr] md:px-10">
          <div>
            <span className="text-[13px] text-muted">02</span>
            <h2 className="mt-6 font-serif text-[46px] leading-none text-ink">Projects</h2>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            {[
              ['BrainNeRF', 'EEG spatial super-resolution with neural fields.'],
              ['Alzheimer\'s Disease', 'Multimodal analysis with EEG, MRI, and olfactory signals.'],
              ['Conductive Hydrogel', 'Biomedical materials project for Challenge Cup.']
            ].map(([title, body]) => (
              <article key={title} className="rounded-[1.2rem] border border-line bg-[#fbfaf7] p-6 transition hover:-translate-y-1 hover:bg-white">
                <h3 className="text-[20px] font-semibold tracking-[-0.03em] text-ink">{title}</h3>
                <p className="mt-4 text-[15px] leading-6 text-muted">{body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="beyond" className="border-t border-line bg-[#fbfaf7]">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-10 px-6 py-24 md:grid-cols-[0.35fr_1fr] md:px-10">
          <div>
            <span className="text-[13px] text-muted">03</span>
            <h2 className="mt-6 font-serif text-[46px] leading-none text-ink">Beyond</h2>
          </div>
          <div className="grid gap-10 md:grid-cols-2">
            <div>
              <p className="text-[13px] font-semibold uppercase tracking-[0.24em] text-clay">Philosophy</p>
              <h3 className="mt-5 text-[34px] font-semibold tracking-[-0.04em] text-ink">让一朵云推动另一朵云。</h3>
              <p className="mt-4 text-[17px] leading-7 text-muted">
                Research, to me, is one way of passing forward the warmth I have received from society.
              </p>
            </div>
            <div className="rounded-[1.2rem] border border-line bg-paper p-6 text-[16px] leading-7 text-muted">
              I enjoy quiet places, books, forests, and moments that make difficult questions feel human again.
            </div>
          </div>
        </div>
      </section>

      <section className="min-h-screen border-t border-line bg-ink text-paper">
        <div className="mx-auto flex min-h-screen max-w-5xl flex-col justify-center px-6 py-24 md:px-10">
          <p className="whitespace-pre-line font-serif text-[38px] leading-[1.35] tracking-[-0.02em] md:text-[58px]">
{`如果有一天，

我的研究能够帮助一个人重新开口说话，

或者帮助一个家庭更早发现疾病，

那么，

那些无数个深夜，

都值得。`}
          </p>
          <div className="mt-12 flex flex-wrap items-center gap-6 text-[15px] text-paper/70">
            <span>—— 让一朵云推动另一朵云</span>
            <a href="mailto:sober_9@foxmail.com" className="underline underline-offset-4">Email</a>
            <a href="https://github.com/Somber9" className="underline underline-offset-4">GitHub</a>
          </div>
        </div>
      </section>
    </main>
  );
}
