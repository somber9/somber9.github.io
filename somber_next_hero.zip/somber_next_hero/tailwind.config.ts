import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        paper: '#F7F3EE',
        ink: '#161512',
        muted: '#6F6B64',
        line: '#DED8CE',
        clay: '#C96F4A',
        purple: '#6E63F7'
      },
      fontFamily: {
        sans: ['var(--font-inter)', 'Inter', 'system-ui', 'sans-serif'],
        serif: ['var(--font-serif)', 'Georgia', 'serif']
      }
    }
  },
  plugins: []
};

export default config;
