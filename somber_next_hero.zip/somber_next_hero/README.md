# Somber Academic Homepage

Next.js + Tailwind academic homepage for Bener Su.

## Local preview

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Build for GitHub Pages

```bash
npm run build
```

Upload the generated `out/` folder contents to the GitHub Pages repository, or set up GitHub Actions later.
